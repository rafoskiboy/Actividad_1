using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    public float walking_speed = 2f;
    public float running_speed = 8f;
    public float jump_force = 7f;
    private Rigidbody rb;
    private Vector3 playerX, playerY, playerZ;
    public float numberOfJumps = 1f;
    public float mouse_sensitivity = 1;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent <Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        

        if (Input.GetKey(KeyCode.W)) 
        {
            transform.Translate(Vector3.forward * walking_speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.back * walking_speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.left * walking_speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * walking_speed * Time.deltaTime);
        }


        if (Input.GetKey(KeyCode.Space) && numberOfJumps>0) 
        {
            transform.Translate(Vector3.up * jump_force * Time.deltaTime);
            numberOfJumps -= 1;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        numberOfJumps = 1;
    }

}

