using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_2 : MonoBehaviour
{

    public float walkingSpeed = 2f;
    public float runningSpeed = 8f;
    public float jumpHeight = 7f;
    private Rigidbody rb;
    public float gravity = -9.81F;
    public float numberOfJumps = 1f;
    public float groundDistance = 0.4f;

    public float mouseSensitivity = 1;
    public Transform playerCamera;

    public LayerMask groundMask = 1;

    //private variables
    private CharacterController controller;
    private Vector3 velocity;
        private bool isGrounded;
    private Transform groundCheck;


    //mouse look variables
    private float xRotation = 0f;
    private float mouseX;
    private float mouseY;

    //movement variables

    private Vector3 move;
    private float x;
    private float z;
    private bool isRunning;
    private float currentSpeed;


    // Start is called before the first frame update
    void Start()
    {
        //get components
        controller = GetComponent<CharacterController>();

        //create ground chaeck point
        CreateGroundCheck();

        //look cursor to center of screen
        Cursor.lockState = CursorLockMode.Locked;

        //ensure we have a camera reference
        if(playerCamera == null) 
        {
            playerCamera = Camera.main?.transform;
            if (playerCamera == null) 
            {
                Debug.LogError("NO CAMERA ASSIGNED AND NO MAIN CAMERA FOUND!");
             
            }
        }

    }

    // Update is called once per frame
    void Update()
    {

        HandleGroundCheck();
        HandleMouseLook();
        HandleMovement();
        HandleJump();
        HandleGravity();

        //apply movement
        controller.Move(move * Time.deltaTime);
     
    }

    void CreateGroundCheck() 
    {
        //create an empty GameObject as child for ground checking
        GameObject groundCheckObj = new GameObject("GroundCheck");
        groundCheckObj.transform.SetParent(transform);
        groundCheckObj.transform.localPosition = new Vector3(0, -controller.height / 2f, 0);
        groundCheck = groundCheckObj.transform;

    }

    void HandleGroundCheck() 
    {
        //check if grounded using sphere cast
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        //reset falling velocity when grounded
        if(isGrounded && velocity.y < 0) 
        {
            velocity.y = -2f; //small negative value to keep grounded
        }
    }

    void HandleMouseLook() 
    {
        if (playerCamera == null) return;

        //get mouse input
        mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        //rotate camera up/down
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);
        playerCamera.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

        //rotate player left right
        transform.Rotate(Vector3.up * mouseX);
    }

    void HandleMovement() 
    {
        //get input
        x = Input.GetAxis("Horizontal");
        z = Input.GetAxis("Vertical");

        //check if running
        isRunning = Input.GetKey(KeyCode.LeftShift);
        currentSpeed = isRunning ? runningSpeed : walkingSpeed;

        //calculate movement direction relative to player
        move = transform.right * x + transform.forward * z;
        move = Vector3.ClampMagnitude(move, 1f) * currentSpeed;

        //add vertical velocity
        move.y = velocity.y;
    }

    void HandleJump() 
    {
        // jump when space is pressed and grounded
        if (Input.GetButtonDown("Jump") && isGrounded) 
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

    }
        void HandleGravity() 
        {
            //apply gravity
            velocity.y += gravity * Time.deltaTime;
        }

    void OnDrawGizmosSelected()
    {

        //draw ground check sphere in scene view
        if (groundCheck != null)
        {
            Gizmos.color = isGrounded ? Color.green : Color.red;
            Gizmos.DrawSphere(groundCheck.position, groundDistance);
        }

    }

    // public methods for external control
    public bool IsGrounded => isGrounded;
    public bool IsRunning => isRunning;
    public float CurrentSpeed => currentSpeed;
    public Vector3 Velocity => controller.velocity;

    //method to toggle cursor lock (useful for pause menus)
    public void ToggleCursorLock() 
    {
        if (Cursor.lockState == CursorLockMode.Locked) 
        {
            Cursor.lockState = CursorLockMode.None;
        }

        else 
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }
}

