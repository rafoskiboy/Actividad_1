using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class SaveCoins : MonoBehaviour
{
    private GameManager gameManager;

    void Start()
    {
        // Obtener la instancia del GameManager
        gameManager = GameManager.instance; 
        if (gameManager == null)
        {
            Debug.LogError("GameManager no encontrado!");
            return;
        }

        // Cargar las monedas guardadas
        string path = Application.persistentDataPath + "/savecoins.txt"; 
        if (File.Exists(path))
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string line = sr.ReadLine();
                if (!string.IsNullOrEmpty(line))
                {
                    gameManager.point = int.Parse(line); // Cargar el valor en point
                }
            }
        }
    }

    private void OnDisable()
    {
        // Guardar las monedas
        string path = Application.persistentDataPath + "/savecoins.txt";
        using (FileStream fs = File.Create(path))
        using (StreamWriter sw = new StreamWriter(fs))
        {
            sw.WriteLine(gameManager.point); // Guardar el valor de point
        }
    }
}